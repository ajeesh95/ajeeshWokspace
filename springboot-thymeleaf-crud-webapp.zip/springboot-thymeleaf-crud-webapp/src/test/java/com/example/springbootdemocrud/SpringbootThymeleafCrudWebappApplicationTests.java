package com.example.springbootdemocrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootThymeleafCrudWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
