package com.example.springbootdemocrud.service;

import java.util.List;

import com.example.springbootdemocrud.model.Employee;

public interface EmployeeService {
	
	List<Employee> getEmployeeList();
	void saveEmployee(Employee employee);
	Employee getEmployeeById(long id);
	void deleteEmployeeById(long id);

}
